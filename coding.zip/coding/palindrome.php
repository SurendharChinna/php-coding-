<?php
// echo "Palindrome!!!:\n";

// $word="MaDam";
// $len=strlen($word);
// //echo $len;
// $isPalindrome=" is not a Palindrome";
// $rev="";
// if($len>0){
//     for($i=$len-1;$i>=0;$i--)
//     {
//         $rev.=$word[$i];
        
//     }
//     if(strtolower($word)==strtolower($rev)) //strtolower($word)==strtolower($rev)
//     {
//         $isPalindrome="is Palindrome";
//     }
// }
// echo "the given word ".$word." ".$isPalindrome;
?>



<?php
$word="nitin";
$len=strlen($word);
$isPalindrome="is not a Palindrome";
$rev='';
if($len>0){
    for($i=$len-1;$i>=0;$i--){
        $rev.=$word[$i];
    }
    echo $rev;
    if(strtolower($word)==strtolower($rev)){
       $isPalindrome=" is Palindrome";
    }
    echo $isPalindrome;
}
//op = nitin is palindrome;
?>