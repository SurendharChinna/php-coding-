<?php

$year =2000;
if(($year %4==0 && $year %100 !=0)||($year %400 == 0))
{
    echo "given year is leap year";
}
else{
    echo "given year is  not leap year";
}
?> 
