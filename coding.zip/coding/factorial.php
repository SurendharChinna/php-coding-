<?php

function factorial($n){
    if($n<=1)
    {
        return 1;
    }
    else{
        return $n *factorial($n-1);
    }
}
$n=4;echo "\n";
echo "Factorial of $n is:".factorial($n);
echo "<br>";
//op Factorial of 4 is:24
?>

<?php
$animals=array("a","b","c","a","d","e","b");
$exa=[];
foreach($animals as $animal){
    
    if(!in_array($animal,$exa)){
        echo $animal."<br>";
    }
    $exa[]=$animal;
    //echo "<br>";
}
echo "<br>";
//op a
// b
// c
// d
// e
?>
<?php 

function fibo($n){
    $n1=0;
    $n2=1;
    $counter = 0;
    while($counter<$n){
        echo ' '.$n1;
        $n3=$n1+$n2;
        $n2=$n1;
        $n1=$n3;
        $counter=$counter+1;

    }
    echo "<br>";
}

$n=11;
fibo($n);

echo "<br>";
//op 0 1 1 2 3 5 8 13 21 34 55

?>
<?php
$word='DAD';
$len=strlen($word);
$isPalindrome=" $word is not a Palindrome";
$rev='';
if($len>0)
{
    for($i=$len-1;$i>=0;$i--){
        $rev.=$word[$i];
    }
    if(strtolower($word)==strtolower($rev)){
        $isPalindrome=" $word is a Palindrome";
    }
    
    echo $isPalindrome;echo "<br>";
}
echo "<br>";

//op DAD is a Palindrome
?>

<?php

$year =4;
if(($year %4==0 && $year %100 !=0)|| ($year %400==0)){
    echo "It is a Leap Year";
}
else{
    echo "It is not a Leap Year";
}
echo '<br>';
echo '<br>';
//op It is a Leap Year
?>
<?php
for($num=1;$num<=100;$num++){
    $isPrime=check_prime($num);
    if($isPrime)
    {
        echo $num." ";
    }
}
function check_prime($num)
{
    for($i=2;$i<=$num/2;$i++){
        if($num%$i==0){
            return 0;
        }
    }
    return 1;
}
echo "<br>";


//op 1 2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97
?>
<?php
function reverse($mystr)
{
    $last=strlen($mystr) -1;
    for($i=$last;$i>=0;$i--)
    {
        echo $mystr[$i];
       
    }
    return 1;
}

reverse('mani');
echo "<br";

//op inam
?>
