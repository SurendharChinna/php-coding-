<?php
$str="surendharatgmail.com";
echo str_replace('at','@',$str);

?>