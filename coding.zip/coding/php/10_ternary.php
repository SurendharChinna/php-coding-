<?php

$a=45;
$b=50;
$c=($a>$b)?$a:$b;
echo $c;
?>