<?php
$a = 5;
$b=6;

echo "Swap of C is : ";
$c=$a;
$a=$b;
$b=$c;
echo " $c ";
?>