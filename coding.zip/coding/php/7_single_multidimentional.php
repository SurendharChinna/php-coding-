<?php
$a = array();
$a[]="suren";
$a[]="akilan";
$a[]="chinta";
print_r($a);
$details["suren"][0]=50;
$details["suren"][1]=70;
$details["suren"][3]=90;
$details["akilan"][1]=70;
$details["akilan"][2]=90;
$details["akilan"][3]=90;
$details["CHINTA"][1]=90;
$details["CHINTA"][2]=70;
$details["CHINTA"][3]=70;
echo "<pre>";
print_r($details);


?>