<?php
// $str="SURENDHAR CHINNA is the father of Chinta";


// echo strrev($str);
// echo "<br>";


$strs="surendhar chinna";
$len = strlen($strs);
for($i=($len-1);$i>=0;$i--)
{
    echo $strs[$i];
    echo "<br>"; 
}
?>