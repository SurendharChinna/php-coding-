<?php

$name[]="surendhar";
$name[]="chinna";
$name[]="durai";
$name[]="suren";
$name[]="chinnadurai";

echo "<pre>";

$names=array_slice($name,2,4);
print_r($names);

$nameses[]="chinta";
$nameses[]='Chintu';

$namer=array_merge($names,$nameses);
print_r($namer);


?>