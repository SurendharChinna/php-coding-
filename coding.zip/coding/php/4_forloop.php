<?php
for($i=10;$i>=1;$i--)
{
    echo $i. "<br>";
}
$i=1;
while($i<=10)
{
    echo $i."<br>";
    $i++;
}

foreach($i as $new=>$n)
{
    echo "new ".$n;
}
?>