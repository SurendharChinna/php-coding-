<?php
$slower="SURENDHAR CHINNA";
echo strtolower("Lower : ".$slower);
echo "<br>";

$supper="surendhar chinna";
echo strtoupper("Upper : ".$supper);
?>