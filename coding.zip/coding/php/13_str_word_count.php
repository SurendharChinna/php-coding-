<?php
$str_word_count="SURENDHAR CHINNA is the father of Chinta";
echo str_word_count($str_word_count);
echo "<pre>";


echo "string length","<br>";

$strlength="surendhar chinna";
echo strlen("Upper : ".$strlength);
?>