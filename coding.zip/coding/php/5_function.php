<?php
function add($a,$b)
{
    $c=$a+$b;
    echo 'Result : '.$c;
}
add(14,11);
?>