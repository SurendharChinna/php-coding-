<?php


echo "Flip of the follwing is ";
$name["surendhar"]="chinna";
$name["akilan"]="akill";
$name["chinta"]="chita";

$names=array_flip($name);
print_r($names);

?>