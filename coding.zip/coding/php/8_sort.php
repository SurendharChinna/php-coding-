<?php
$a[]="suren";
$a[]="akilan";
$a[]="chinta";
sort($a);
print_r($a);

echo "<pre>";
rsort($a);
print_r($a);
// echo "rsort",$a;
?>