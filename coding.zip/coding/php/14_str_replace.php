<?php
$str="SURENDHAR CHINNA is the father of Chinta";
echo "<br>";

echo str_repeat($str,3);




?>