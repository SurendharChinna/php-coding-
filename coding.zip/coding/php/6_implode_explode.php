<?php
$res = "mani,surendhar,akilan,surya,chinta";
$result=explode(' , ',$res."<br>");
 print_r($result);  

foreach($result as $newresult)
{
    echo 'New result '.$newresult.'<br>';
}

$newresults=implode(',',$result);
echo "<br>";
echo $newresults;

                                                                                                    
                                                                                                    
                                                                                                    
?>