<?php
$n1=0;
$n2=1;
$limit=10;
echo $n1." ".$n2." ";
for($i=0;$i<$limit;$i++)
{
    $n3=$n1+$n2;
    echo $n3." ";
    $n1=$n2;
    $n2=$n3;
}

?>