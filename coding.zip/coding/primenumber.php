<?php
// echo " Check Prime Number.<br>";

// for($num=1;$num<=100;$num++){
//     $isPrime=check_prime($num);
//    if($isPrime){
//     echo $num. " ";
//    }
// }
//     function check_prime($num)
//     {
//         if($num==1)
//         {
//             return 0;
//         }
//         for($i=2;$i<=$num/2;$i++)
//         {
//         if($num%$i==0)
//         {
//             return 0;
//         }
//         }
    
//     return 1;
// }

?> 

<?php
for($num=1;$num<=100;$num++){
    $isPrime=check_prime($num);
    if($isPrime){
        echo $num. " ";
    }
}
function check_prime($num){
    if($num==0){
        return 0;
    }
    for($i=2;$i<=$num/2;$i++){
        if($num%$i==0){
            return 0;
        }
    }
    return 1;
}
//op
// 1 2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97
?>