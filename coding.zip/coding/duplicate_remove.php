<?php
 echo "Remove Duplicate array <br>";

 $animals=array("lion","tiger","bear","deer","lion","tiger");
 $excludeDup=[];
 foreach($animals as $animal)
 {
    if(!in_array($animal,$excludeDup))
    {
        // echo "After Duplicate entry:";
        echo $animal."<BR>";
    }
    $excludeDup[]=$animal;
 }
//  //print_r($excludeDup);

//op=remove duplicate with answer
// lion
// tiger
// cheetah
//bear
// deer
?>

<?php
$animals=array("lion","tiger","cheetah","lion","tiger","deer","deer");
$excludeDup=[];
foreach($animals as $animal){
    if(in_array($animal,$excludeDup))
    {
        echo $animal."<br>";
    }
    $excludeDup[]=$animal;
}
//op=show duplicate only
// lion
// tiger
//deer

?>